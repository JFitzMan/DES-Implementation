Assignment 5, Part C: A Hybrid Protocol

Partners: 		Jordan Fitzpatrick, Grade ID: 28
			Sean Gallardo, Grade ID: 46
			
Included:
			Chat.java, DES.java, RSA.java, getopt.jar, and a Makefile
			
To use:
			After extracting files, open a command line window in the folder.
			Run 'make'. This should create the necessary .class files.
			
			To run the chat client, run "make run-alice" and "make run-bob" in two different command line windows.
			They should be able to communicate.
			Alice should lay down and wait for Bob, then when Bob connects he will generate a new DES key and send it to Alice.
			From there, the chat channel will open, you should be able to send encrypted messages back and forth. 
			To end the chat, closing one of the command line windows or force quitting one of the running programs will suffice.
			
			For convenience, keys and moduluses have been provided in the Makefile commands by default.
			To replace these, see the "Makefile" section.

Makefile:
			If running a Mac, you will have to replace the ';' (semicolon) after the jar in the JAR section with a ':' (colon).
			This is due to the inconsistencies between Mac and Windows systems.
 
			Also available is the 'make clean' command, which will delete all .class files in the folder. 
			If on a Mac you'll have to replace the "del" with "rm".			


			The 'run-alice', "run-bob", 'run-h', and 'run-RSA' commands are available to you. 
			
			The alice and bob commands have been pre-filled with generated RSA keys. 
			If you wish to test the Chat client and make sure it is not hard coded, 
				you can run "make run-RSA" to generate a new RSA key pair.
			You will need to run it once each for both Alice and Bob. 
			Then copy and paste the pairs into the corresponding places of the 'alice' and 'bob' commands in the Makefile.
			You can then run the Chat client as laid out in the "To use" section.
			
			One change was made from the spec because we ran into issues.
			The -A (big A) argument is used for Alice's public key, and -B (big B) is for Bob's public key.
			Everything else is as it is in the spec. 
			
			You will find these Makefile commands follow the execution commands as laid out in the spec, 
				they have just been streamlined for convenience. 