//28_Jordan_Fitzpatrick
//46_Sean_Gallado
//partners

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import gnu.getopt.Getopt;
import gnu.getopt.LongOpt;

public class Chat {
	static String host;
	static int port;
	static Socket s;
	static String username;
	
	static String privateKeyAlice;
	static String privateKeyBob;
	static String publicKeyAlice;
	static String publicKeyBob;
	static String aliceModulus;
	static String bobModulus;
	static String desKey;
	
	public static void main(String[] args) throws IOException {

		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
//		Process command line arguments
		pcl(args);

		/*
		System.out.println(username);
		System.out.println("Alice public: " + publicKeyAlice);
		System.out.println("Alice private: " + privateKeyAlice);
		System.out.println("Alice mod: " + aliceModulus);
		System.out.println("Bob public: " + publicKeyBob);
		System.out.println("Bob private: " + privateKeyBob);
		System.out.println("Bob mod: " + bobModulus);
		*/
		
//		set up server, or join server
		setupServer();
		
//		Set up username
		handShake();
		
		System.out.println("Welcome to the encrypted chat program.\nChat starting below:");

		
//		Make thread to print out incoming messages...
		ChatListener chatListener = new ChatListener();
		chatListener.start();
		
//		loop through sending and receiving messages
		PrintStream output = null;
		try {
			output = new PrintStream(s.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		String input = "";
		while(true){
			
			input = keyboard.nextLine();
			input = username + ": " + input;
						
			input = encrypt(input);
			output.println(input);
			output.flush();	
		}

	}


	private static String encrypt(String input) {
		String inputBin = input;
		byte[] inputBytes = inputBin.getBytes();
	
		BigInteger bytes = new BigInteger(inputBytes);
		BigInteger key = new BigInteger(desKey, 16);
		//System.out.println("Input:           " + bytes.toString());
		BigInteger encrypted = bytes.xor(key);
		//System.out.println("Encrypted input: " + encrypted.toString());
		
		return encrypted.toString();
	}

	private static String decrypt(String inputStr){
		//System.out.println("Encrypted input received: " + inputStr);
		BigInteger encrypted = new BigInteger(inputStr);
		BigInteger key = new BigInteger(desKey, 16);
		BigInteger decrypted = encrypted.xor(key);	
		
		//System.out.println("Decrpted output:          "+ decrypted.toString());
		byte[] outputBytes = decrypted.toByteArray();
		String output = null;
		try {
			output = new String(outputBytes, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		//System.out.println(output);
		
		return output;
	}


	/**
	 * Upon running this function it first tries to make a connection on 
	 * the given ip:port pairing. If it find another client, it will accept
	 * and leave function. 
	 * If there is no client found then it becomes the listener and waits for
	 * a new client to join on that ip:port pairing. 
	*/
	private static void setupServer() {
		try {
			// This line will catch if there isn't a waiting port
			s = new Socket(host, port);
			
		} catch (IOException e1) {
			System.out.println("There is no other client on this IP:port pairing, waiting for them to join.");
			
			try {
				ServerSocket listener = new ServerSocket(port);
				s = listener.accept();
				listener.close();
				
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(1);
			}

		}
		System.out.println("Client Connected.");

	}

	private static void handShake(){
		
		System.out.println("Hello " + username + "! Initializing...");
		
		if(username == "bob"){
			String message = null;
			desKey = DES.genDESkey();
			message = RSA.RSAencrypt(desKey, aliceModulus, publicKeyAlice);
			//System.out.println("DES key encrypted:\n" + message);
			PrintStream output = null;
			try {
				output = new PrintStream(s.getOutputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("Sending session key...");
			output.println(message);
			output.flush();
			return;
		}
		
		else if(username == "alice"){
			String message = null;
			BufferedReader input = null;
			try {
				input = new BufferedReader(new InputStreamReader(s.getInputStream()));
			} catch (IOException e1) {
				e1.printStackTrace();
				System.err.println("System would not make buffer reader");
				System.exit(1);
				}
			String cipher;
			try {
//				Read lines off the scanner
				cipher = input.readLine();
				//System.out.println("Cipher: " + cipher);
				message = RSA.RSAdecrypt(cipher, aliceModulus, privateKeyAlice);
				desKey = message;
				System.out.println("Session key retreived!");
				if(cipher == null){
					System.err.println("The other user has disconnected, closing program...");
					System.exit(1);
				}
				} catch (IOException e) {
					e.printStackTrace();
					System.exit(1);
				}
		}
			
	}

	
	/**
	 * This function Processes the Command Line Arguments.
	 * Right now the three accepted Arguments are:
	 * -p for the port number you are using
	 * -i for the IP address/host name of system
	 * -h for calling the usage statement.
	 */
	private static void pcl(String[] args) {
		/*
		 * http://www.urbanophile.com/arenn/hacking/getopt/gnu.getopt.Getopt.html
		*/
		LongOpt[] longopts = new LongOpt[2];
		longopts[0] = new LongOpt("alice", LongOpt.NO_ARGUMENT, null, 1);
		longopts[1] = new LongOpt("bob", LongOpt.NO_ARGUMENT, null, 2);
		Getopt g = new Getopt("Chat Program", args, "hp:i:a:A:b:B:m:n:", longopts);
		int c;
		String arg;
		while ((c = g.getopt()) != -1){
		     switch(c){
		     	  case 1:
		     		  username = "alice";
		     		  break;
		     	  case 2:
		     		  username = "bob";
		     		  break;
		          case 'p':
		        	  arg = g.getOptarg();
		        	  port = Integer.parseInt(arg);
		        	  break;
		          case 'i':
		        	  arg = g.getOptarg();
		        	  host = arg;
		        	  break;
		          case 'a':
		        	  arg = g.getOptarg();
		        	  privateKeyAlice = arg;
		        	  break;
		          case 'A':
		        	  arg = g.getOptarg();
		        	  publicKeyAlice = arg;
		        	  break;
		          case 'm':
		        	  arg = g.getOptarg();
		        	  aliceModulus = arg;
		        	  break;
		          case 'b':
		        	  arg = g.getOptarg();
		        	  privateKeyBob = arg;
		        	  break;
		          case 'B':
		        	  arg = g.getOptarg();
		        	  publicKeyBob = arg;
		        	  break;
		          case 'n':
		        	  arg = g.getOptarg();
		        	  bobModulus = arg;
		        	  break;
		          case 'h':
		        	  callUsage(0);
		          case '?':
		        	  break; // getopt() already printed an error
		            //
		          default:
		              break;
		       }
		   }
	}

	/**
	 * A helper function that prints out the useage help statement
	 * and exits with the given exitStatus
	 * @param exitStatus
	 */
	private static void callUsage(int exitStatus) {
		
		String useage = "";
		useage += "-h   	No args\n";
		useage += "      	Usage information.\n\n";
		useage += "--alice	Usage: --alice -a <Alice Private Key> -m <Alice Modulus> -B <Bob Public Key> -n <Bob Modulus> -p Port -i IP Address\n";
		useage += "       	This is what Alice runs. She knows Bob's public key, along with the port and IP address on which to talk to him.\n";
		useage += "       	Starts up first, then waits for Bob. \n\n";
		useage += "--bob	Usage: --bob -b <Bob Private Key> -n <Bob Modulus> -A <Alice Public Key> -m <Alice Modulus> -p Port -i IP Address\n";
		useage += "       	This is what Bob runs. He knows Alice's public key, along with the port and IP address on which to talk to her.\n";
		useage += "       	Starts up by initializing the hybrid protocol, generates a DES key, encrypts it with Alice's public key, and sends her the encrypted package.\n";
		useage += "       	Once they are done with the handshake, they exchange encrypted messages from the command line. \n\n";
		
		System.err.println(useage);
		System.exit(exitStatus);
		
	}

	/**
	 * A private class which runs as a thread listening to the other 
	 * client. It prints out the message on screen.
	 */
	static private class ChatListener implements Runnable {
		private Thread t;
		ChatListener(){
		}
		
		@Override
		public void run() {
			BufferedReader input = null;
			try {
				input = new BufferedReader(new InputStreamReader(s.getInputStream()));
			} catch (IOException e1) {
				e1.printStackTrace();
				System.err.println("System would not make buffer reader");
				System.exit(1);
			}
			String inputStr;
			while(true){
				try {
//					Read lines off the scanner
					inputStr = input.readLine();
					inputStr = decrypt(inputStr);
					System.out.println(inputStr);
					
					if(inputStr == null){
						System.err.println("The other user has disconnected, closing program...");
						System.exit(1);
					}
					
				} catch (IOException e) {
					e.printStackTrace();
					System.exit(1);
				}
			}
		}
		   
		public void start(){
			if (t == null){
				t = new Thread(this);
				t.start();
			}
		}
	}
}
