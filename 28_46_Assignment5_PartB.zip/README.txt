Assignment 5, Part B: Public-Key Cryptography

Partners: 		Jordan Fitzpatrick, Grade ID: 28
			Sean Gallardo, Grade ID: 46
			
Included:
			RSA.java, DES.java, getopt.jar, and a Makefile
			
To use:
			After extracting files, open a command line window in the folder.
			Run 'make'. This should create the necessary .class files.
			
			To run the RSA encryption, first run "make run-e" and then "make run-d".
			
			For convenience, keys, moduluses, and input values have been provided in the Makefile commands by default.
			To replace these, see the "Makefile" section.			


Makefile:
			If running a Mac, you will have to replace the ';' (semicolon) after the jar in the JAR section with a ':' (colon).
			This is due to the inconsistencies between Mac and Windows systems. 

			Also available is the "make clean" command, which will delete all .class files in the folder. 
			If on a Mac you'll have to replace the "del" with "rm".
			

			The 'run-e', 'run-d', 'run-k', 'run-h', and 'run-DES' commands are available to you. 

			The e and d commands have been pre-filled with keys and input values.
			If you wish to test the encryption and make sure it is not hard coded, 
				you can run "make run-DES" to generate a new DES key.
			Then, run "make run-k" to generate a new RSA key pair.
			You will need to copy and paste these values into their corresponding positions in the 'run-e' (and 'run-d') command in the makefile. 
			Then, run "make run-e" to encrypt the input value and receive your cipher.
			Copy and paste the cipher into the corresponding position in the 'run-d' command.
			Finally, run "make run-d" to decrypt the cipher. 

			You will find these Makefile commands follow the execution commands as laid out in the spec, 
				they have just been streamlined for convenience. 
 
